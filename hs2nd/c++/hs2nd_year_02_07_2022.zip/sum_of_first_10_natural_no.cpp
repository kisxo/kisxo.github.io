#include<iostream.h>
#include<conio.h>
void main()
{
	clrscr();
	int sum;
	
	for(int i=1; i<11; i++)
		{
			sum+=i;
			cout<<sum<<endl;
		}
		
	getch();
}