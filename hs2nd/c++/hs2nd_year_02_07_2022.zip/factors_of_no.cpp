#include<iostream.h>
#include<conio.h>
void main()
{
	clrscr();
	int x;
	
	cout<<"Enter a number to find its factors : ";
	cin>>x;
	
	for(int i=1; i<=x; i++)
		{
			if(x%i==0)
				{
					cout<<i<<endl;
				}
		}
	
	
	getch();
}