#include <iostream.h>
#include <conio.h>
void main()
{
	clrscr();
	
	int x,y,z;
	cout<<"Program to find odd numbers between 2 numbers \n";
	cout<<"1st numbet : ";
	cin>>x;
	cout<<"2nd numbet : ";
	cin>>y;
	
	z=x;
	
	if(x%2==1)
		{	int i1=1;	
			
			while(z<y)
				{
					z=x+(2*i1);
					i1++;
					
					if(z>=y){break;};
					cout<<z<<endl;		
				}	
		}
	else{
			int i2=1;	
			
			while(z<y)
				{
					z=x+((2*i2)-1);
					i2++;
					
					if(z>=y){break;};
					cout<<z<<endl;		
				}
		}
	
	getch();
}