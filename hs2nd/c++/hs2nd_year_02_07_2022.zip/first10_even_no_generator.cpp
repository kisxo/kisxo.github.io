#include <iostream.h>
#include <conio.h>
void main()
{
	clrscr();
	
	for(int i=1; i<11; i++)
		{
			cout<<(2*i)<<endl;
		}
	
	getch();
}