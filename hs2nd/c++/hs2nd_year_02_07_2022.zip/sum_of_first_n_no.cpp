#include<iostream.h>
#include<conio.h>
void main()
{
	clrscr();
	int x,y;
	
	cout<<"Enter a number to find it's sum : ";
	cin>>x;
	
	for(int i=1; i<=x; i++)
		{
			y+=i;
			cout<<y<<endl;
		}
	
	getch();
}