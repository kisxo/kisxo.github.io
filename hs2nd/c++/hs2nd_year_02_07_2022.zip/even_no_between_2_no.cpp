#include <iostream.h>
#include <conio.h>
void main()
{
	clrscr();
	
	int x,y,z;
	cout<<"Enter 2 Number to find even numbers between them \n";
	cout<<"1st numbet : ";
	cin>>x;
	cout<<"2nd numbet : ";
	cin>>y;
	
	z=x;
	
	if(x%2==0)
		{	int i1=1;	
			
			while(z<y)
				{
					z=x+(2*i1);
					i1++;
					
					if(z>=y){break;};
					cout<<z<<endl;		
				}	
		}
	else{
			int i2=1;	
			
			while(z<y)
				{
					z=x+((2*i2)-1);
					i2++;
					
					if(z>=y){break;};
					cout<<z<<endl;		
				}
		}
	
	getch();
}