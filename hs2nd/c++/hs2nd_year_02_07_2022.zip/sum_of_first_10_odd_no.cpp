#include <iostream.h>
#include <conio.h>
void main()
{
	clrscr();
	int sum;
	
	for(int i=1; i<6; i++)
		{
			sum+=(2*i)-1;
			cout<<sum<<endl;
		}
	
	getch();
}