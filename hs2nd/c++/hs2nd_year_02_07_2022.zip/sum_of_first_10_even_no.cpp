#include <iostream.h>
#include <conio.h>
void main()
{
	clrscr();
	int sum;
	
	for(int i=1; i<11; i++)
		{
			sum+=2*i;
			cout<<sum<<endl;
		}
	
	getch();
}