#include <iostream.h>
#include <conio.h>
void main()
{
	clrscr();
	int x,y;
	
	cout<<"Enter a number to find the sum of nth odd term : ";
	cin>>x;
	for(int i=1; i<=x; i++)
		{
			y+=(2*i)-1;
			cout<<y<<endl;
		}
	
	getch();
}