#include<iostream.h>
#include<conio.h>

void main()
{
	clrscr();
	
	int x[5];
	
	cout<<"Enter 5 number to increment each by 2 \n";
	
	for(int i=0; i<5; i++)
		{
			cout<<"Enter no: ";
			cin>>x[i];	
		}
		
	for(int i=0; i<5; i++)
		{
			x[i]+=2;
			cout<<x[i]<<endl;
		}
	
	getch();	
}