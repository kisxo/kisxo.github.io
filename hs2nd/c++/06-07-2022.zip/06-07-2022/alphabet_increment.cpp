#include<iostream.h>
#include<conio.h>

void main()
{
	clrscr();
	
	char x[5];
	int i;
	
	cout<<"Enter 5 letters to print its successor letter \n";
	
	for( i=0; i<5; i++)
		{
			cout<<"Enter a letter :";
			cin>>x[i];
		}
		
	cout<<"New letters are \n";
	for( i=0; i<5; i++)
		{
			cout<<x[i]<<" = ";
			
			//simple ways but not works for 'z'
			
			if(x[i]=='z')
				{
					cout<<"a\n";
				}
			else{
					x[i]++;
					cout<<x[i]<<endl;
				}	
		}
	
	
	getch();	
}