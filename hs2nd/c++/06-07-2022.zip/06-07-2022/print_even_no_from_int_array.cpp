#include<iostream.h>
#include<conio.h>

void main()
{
	clrscr();
	
	int x[10];
	
	cout<<"Enter 10 number to print out only even numbers\n";
	
	for(int i=0; i<10; i++)
		{
			cout<<"Enter no: ";
			cin>>x[i];	
		}
	
	cout<<"Even numbers are :";
			
	for(int i=0; i<10; i++)
		{
			if(x[i]%2==0)
				{
					cout<<x[i]<<',';
				}
		}
	
	getch();	
}